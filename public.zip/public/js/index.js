console.log("Hello World");
const title = document.querySelector("h1");
console.log(title);